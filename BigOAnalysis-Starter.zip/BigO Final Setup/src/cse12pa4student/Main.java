package cse12pa4student;

import static cse12pa4mysteries.Mysteries.*;

import cse12pa4mysteries.Mysteries;

public class Main {
	
	public static void main(String[] args) {
		Mysteries.mysteryA(50);
	}
}
